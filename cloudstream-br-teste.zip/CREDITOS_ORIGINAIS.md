<div align="center"> 

# saimuelrepo

<img src="https://img.shields.io/badge/CloudStream-blue?style=for-the-badge&logo=android" alt="CloudStream 4+">
<img src="https://img.shields.io/badge/Status-Estável-yellow?style=for-the-badge" alt="Experimental">

[![Licença GPL-3.0](https://img.shields.io/badge/%F0%9F%93%84_Licen%C3%A7a-GPL%203.0-8BC34A?style=for-the-badge&logo=book)](https://www.gnu.org/licenses/gpl-3.0.html)

### A Primeira Extensão Brasileira do CloudStream

</div>

---
<div align="center">
  
###  Sobre o Projeto
- **Atualmente trabalhando em:** [saimuelrepo](https://github.com/saimuelbr/saimuelrepo)
- **Linguagem:** **Kotlin** 
  
</div>

---

#  Adicione a Extensão

[![Passo 1](https://img.shields.io/badge/Abrir_CloudStream-2196F3?style=flat-square&logo=android)]()
[![Passo 2](https://img.shields.io/badge/Configurações→Extensões-4CAF50?style=flat-square&logo=settings)]()
[![Passo 3](https://img.shields.io/badge/Adicionar_Repositório-FF9800?style=flat-square&logo=plus)]()
[![Passo 4](https://img.shields.io/badge/Digite_o_Link_Curto-9C27B0?style=flat-square&logo=clipboard)]()

**Link Curto:**
`saim`

---

###  Linguagens e Ferramentas
<p align="left">
<a href="https://developer.android.com" target="_blank" rel="noreferrer">
<img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/android/android-original-wordmark.svg" alt="android" width="50" height="50"/>
</a> 
<a href="https://git-scm.com/" target="_blank" rel="noreferrer">
<img src="https://www.vectorlogo.zone/logos/git-scm/git-scm-icon.svg" alt="git" width="50" height="50"/>
</a> 
<a href="https://kotlinlang.org" target="_blank" rel="noreferrer">
<img src="https://www.vectorlogo.zone/logos/kotlinlang/kotlinlang-icon.svg" alt="kotlin" width="50" height="50"/>
</a> 
</p>

---

<div align="center">
  
[![CloudStream GitHub](https://img.shields.io/badge/_CloudStream_GitHub-181717?style=for-the-badge&logo=github)](https://github.com/recloudstream/cloudstream)
[![Commits](https://img.shields.io/github/last-commit/saimuelbr/saimuelrepo?style=for-the-badge&label=%20Último%20commit&color=9C27B0)](https://github.com/saimuelbr/saimuelrepo/activity)
[![Tamanho do repositório](https://img.shields.io/github/repo-size/saimuelbr/saimuelrepo?style=for-the-badge&label=%20Tamanho%20do%20repo&color=FF9800)](https://github.com/saimuelbr/saimuelrepo)
[![Stars](https://img.shields.io/github/stars/saimuelbr/saimuelrepo?style=for-the-badge&label=%20Stars&color=FFD700)](https://github.com/saimuelbr/saimuelrepo/stargazers)

</div>

---


### DMCA
Este projeto tem caráter meramente educacional e funciona de forma semelhante a um navegador comum, apenas buscando arquivos de vídeo disponíveis publicamente na internet.

Nenhum tipo de conteúdo é hospedado por este repositório ou pelo aplicativo CloudStream. Qualquer conteúdo acessado é hospedado por sites de terceiros. O uso é de total responsabilidade do usuário, que deve cumprir as leis locais. Se você acredita que algum conteúdo viola direitos autorais, entre em contato diretamente com o provedor que hospeda os arquivos.

<div align="center">
  
[![Deixe uma Star](https://img.shields.io/badge/_Deixe_uma_Star_no_Repo-4CAF38?style=for-the-badge&logo=github&logoColor=black)]()

</div>
